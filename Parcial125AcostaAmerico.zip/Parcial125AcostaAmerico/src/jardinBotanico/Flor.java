package jardinBotanico;

public class Flor extends Planta{
    
    private final Temporada temporadaFlorecimiento;

    public Flor(String nombre, String ubicacion, String climaProspero, Temporada temporadaFlorecimiento) {
        super(nombre, ubicacion, climaProspero);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }

    @Override
    public String toString() {
        return super.toString() + "temporadaFlorecimiento= " + temporadaFlorecimiento;
    }



    
    
    
    
    
    
}
