package jardinBotanico;

public class PlantaDensidadException extends RuntimeException{
    private static final String MESSAGE = "!!!!!!!!!!!! Densidad fuera de Rango !!!!!!!!!!!! ";
    
    public PlantaDensidadException(){
        super(MESSAGE);
    }
}
