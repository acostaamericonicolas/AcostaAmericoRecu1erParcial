package jardinBotanico;

public interface Podable {
    void podarPlantas();
}
