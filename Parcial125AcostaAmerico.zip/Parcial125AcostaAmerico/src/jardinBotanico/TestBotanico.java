package jardinBotanico;

import java.util.ArrayList;
import java.util.List;

public class TestBotanico {


    public static void main(String[] args) {
        //List<Planta> plantas = new ArrayList<>();
        Botanico plantas = new Botanico();

        //Botanico jardinbotanico = new Botanico();
        
        Arbol arbol = new Arbol("Roble", "norte", "Verano", 5);
        Flor flor = new Flor("jazmin", "fondo", "Verano",Temporada.OTONIO);
        Arbol arbol2 = new Arbol("Roble", "norte", "Otonio", 1);
        Flor flor2 = new Flor("rosa", "frente", "Invierno",Temporada.OTONIO);
        Arbusto arbusto = new Arbusto("arbolito", "frente", "Verano", 11);

        
        try {
            
        plantas.agregarPlanta(arbol);
        plantas.agregarPlanta(flor);
        plantas.agregarPlanta(arbusto);
        plantas.agregarPlanta(arbol2);
        plantas.agregarPlanta(flor2);
        
        } catch(PlantaRepetidaException | PlantaDensidadException ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println("--------------");
        
        plantas.mostrarPlantas();
        
        System.out.println("--------------");
        
        plantas.podarPlantas();

    }
    
}
