package jardinBotanico;

import java.util.Objects;

public abstract class Planta{

    private final String nombre;
    private final String ubicacion;
    private final String climaProspero;

    public Planta(String nombre, String ubicacion, String climaProspero) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.climaProspero = climaProspero;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.nombre);
        hash = 97 * hash + Objects.hashCode(this.ubicacion);
        return hash;
    }

    @Override
    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if(o == null || (o.getClass() != getClass())){
            return false;     
        }
        Planta other = (Planta) o; //casteo el objeto "o" a Planta.
        return this.nombre.equals(other.nombre) && this.ubicacion.equals(ubicacion);
        }
    
    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Planta: " + "nombre= " + nombre + " ubicacion= " + ubicacion + " clima prospero= " + climaProspero + ' ';
    }
    
    
    
    
}

