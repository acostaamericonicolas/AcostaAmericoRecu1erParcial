package jardinBotanico;

public class Arbol extends Planta implements Podable{
    private final int alturaMaxima;

    public Arbol(String nombre, String ubicacion, String climaProspero,int alturaMaxima) {
        super(nombre, ubicacion, climaProspero);
        this.alturaMaxima = alturaMaxima;        
    }
    
    @Override
    public void podarPlantas() {
        System.out.println("Podando Arbol");
    }

    @Override
    public String toString() {
        return super.toString() + "altura maxima= " + alturaMaxima;
    }

    
}
