package jardinBotanico;

public class PlantaRepetidaException extends RuntimeException{
    private static final String MESSAGE = "!!!!!!!!!!!! La planta YA ESTA EN LA LISTA !!!!!!!!!!!! ";
    
    public PlantaRepetidaException(){
        super(MESSAGE);
    }
}
