package jardinBotanico;

public class Arbusto extends Planta implements Podable{
    private static final int FOLLAJE_MAX = 10;
    private static final int FOLLAJE_MIN = 1;
    private final int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String climaProspero, int densidadFollaje) {
        super(nombre, ubicacion, climaProspero);
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public void podarPlantas() {
        System.out.println("Podando Arbusto");
    }

    @Override
    public String toString() {
        return super.toString() + " densidadFollaje=" + densidadFollaje;
    }

    public boolean validarDensidad(){
    return densidadFollaje >= FOLLAJE_MIN && densidadFollaje <= FOLLAJE_MAX;
    }
    
    
    
    

    
    
    
    
}
