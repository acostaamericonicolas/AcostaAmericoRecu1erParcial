package jardinBotanico;

import java.util.ArrayList;
import java.util.List;

public class Botanico {
    private final List<Planta> plantas;

    public Botanico() {
        this.plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta)throws PlantaRepetidaException{
        if (planta == null || plantas.contains(planta)){
            throw new PlantaRepetidaException();
        }
        if(planta instanceof Arbusto &&!((Arbusto) planta).validarDensidad()){
            throw new PlantaDensidadException();
        }
        plantas.add(planta);
    }

    public void mostrarPlantas(){
        if(plantas.isEmpty()){
            System.out.println("No hay plantas");
        }
        else{
            for (Planta p : plantas){
            System.out.println(p);
            }        
        } 
    }
 
    public void podarPlantas(){
        System.out.println("iniciando poda...");
        for(Planta planta : plantas){
            if(planta instanceof Podable podable){
                podable.podarPlantas();
            }
            else{
                System.out.println("La flor " +planta.getNombre() + " no puede ser podada.");
            }
                
        }
    }
 
}
